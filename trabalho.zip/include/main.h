/**
 * Trabalho Prático 1 - Organizacao de Arquivos
 * Nome: João Pedro Favoretti (11316055)
 * Nome: Lucas Pilla (10633328)
 */

#ifndef _MAIN_H_
#define _MAIN_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Declaracao de funcoes fornecidas no trabalho */
void binarioNaTela(char *nomeArquivoBinario);
void scan_quote_string(char *str);

#endif