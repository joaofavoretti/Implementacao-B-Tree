/**
 * Trabalho Prático 1 - Organizacao de Arquivos
 * Nome: João Pedro Favoretti (11316055)
 * Nome: Lucas Pilla (10633328)
 */

#ifndef _COMANDOS_H_
#define _COMANDOS_H_

void comando_1();
void comando_2();
void comando_3();
void comando_4();
void comando_5();
void comando_6();
void comando_7();
void comando_8();

#endif
